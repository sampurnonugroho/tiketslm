<script src="<?=base_url()?>constellation/assets/equipment/jquery-3.4.1.min.js"></script>
<link href="<?=base_url()?>constellation/assets/equipment/select2.min.css" rel="stylesheet" />
<script src="<?=base_url()?>constellation/assets/equipment/select2.min.js"></script>
	
	<select id="">
		<option> - SELECT FR - </option>
	</select>
	<select id="">
		<option> - SELECT TO - </option>
	</select>
<script>

</script>